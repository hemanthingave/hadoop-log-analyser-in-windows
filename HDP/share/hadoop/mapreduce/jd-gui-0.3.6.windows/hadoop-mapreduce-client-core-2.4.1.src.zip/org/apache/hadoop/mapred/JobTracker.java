/*  1:   */ package org.apache.hadoop.mapred;
/*  2:   */ 
/*  3:   */ public class JobTracker
/*  4:   */ {
/*  5:   */   public static enum State
/*  6:   */   {
/*  7:32 */     INITIALIZING,  RUNNING;
/*  8:   */     
/*  9:   */     private State() {}
/* 10:   */   }
/* 11:   */ }


/* Location:           C:\HDP\share\hadoop\mapreduce\jd-gui-0.3.6.windows\hadoop-mapreduce-client-core-2.4.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.JobTracker
 * JD-Core Version:    0.7.0.1
 */