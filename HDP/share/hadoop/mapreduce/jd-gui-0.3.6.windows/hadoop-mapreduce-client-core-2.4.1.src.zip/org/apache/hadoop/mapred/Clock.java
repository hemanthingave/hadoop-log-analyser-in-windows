/*  1:   */ package org.apache.hadoop.mapred;
/*  2:   */ 
/*  3:   */ class Clock
/*  4:   */ {
/*  5:   */   long getTime()
/*  6:   */   {
/*  7:26 */     return System.currentTimeMillis();
/*  8:   */   }
/*  9:   */ }


/* Location:           C:\HDP\share\hadoop\mapreduce\jd-gui-0.3.6.windows\hadoop-mapreduce-client-core-2.4.1.jar
 * Qualified Name:     org.apache.hadoop.mapred.Clock
 * JD-Core Version:    0.7.0.1
 */