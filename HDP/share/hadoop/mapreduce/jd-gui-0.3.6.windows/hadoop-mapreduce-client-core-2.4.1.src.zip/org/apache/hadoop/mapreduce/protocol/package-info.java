package org.apache.hadoop.mapreduce.protocol;

import org.apache.hadoop.classification.InterfaceAudience.Private;
import org.apache.hadoop.classification.InterfaceStability.Stable;

@InterfaceAudience.Private
@InterfaceStability.Stable
abstract interface package-info {}


/* Location:           C:\HDP\share\hadoop\mapreduce\jd-gui-0.3.6.windows\hadoop-mapreduce-client-core-2.4.1.jar
 * Qualified Name:     org.apache.hadoop.mapreduce.protocol.package-info
 * JD-Core Version:    0.7.0.1
 */